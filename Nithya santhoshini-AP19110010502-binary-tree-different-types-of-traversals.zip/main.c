/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h> 
#include <stdlib.h> 
struct node 
{ 
     int data; 
     struct node* left; 
     struct node* right; 
}; 
void preorder(struct node* root) 
{ 
     if (root==NULL) 
          return; 
     printf("%d ",root->data);
     preorder(root->left); 
     preorder(root->right); 
} 
void Inorder(struct node* root) 
{ 
     if (root==NULL) 
          return; 
  
     Inorder(root->left);
     printf("%d ", root->data);   
     Inorder(root->right); 
} 
void postorder(struct node* root) 
{ 
     if (root==NULL) 
          return; 
  
     
     postorder(root->left);
     postorder(root->right); 
     printf("%d ", root->data);   
} 

struct node* createnode(int data)
{ 
     struct node* newnode = malloc(sizeof(struct node)); 
     newnode->data = data; 
     newnode->left = NULL; 
     newnode->right = NULL; 
  
     return(newnode);
}
void main()
{
    struct node* root=createnode(1);
    root->left=createnode(6);
    root->right=createnode(7);
    root->left->left=createnode(9);
    root->left->right=createnode(54);
    printf("\npreorder traversal\n");
    preorder(root);
    printf("\ninorder traversal\n");
    Inorder(root);
    printf("\npostorder traversal\n");
    postorder(root);
    
}