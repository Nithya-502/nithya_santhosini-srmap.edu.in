/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{ int x,n,s=0;printf("enter no:of elements:");
scanf("%d",&n);int i,a[i];
{
printf("enter the numbers:");
for(i=0;i<n;i++){
scanf("%d",&a[i]);
}}
printf("enter the number you want to search:");
scanf("%d",&x);
for(i=0;i<5;i++){
if (a[i]==x)
 s=s+1;}
if(s>0)
printf("Number found");
else
printf("Number not found");
 
return 0;}