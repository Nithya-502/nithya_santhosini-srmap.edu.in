/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h> 
int main()
{ int x,n,mid,s=0;
printf("enter no:of elements:");
scanf("%d",&n);
printf("Enter numbers in ascending order\n");
int i,a[i];
{
printf("enter the numbers:");
for(i=0;i<n;i++){
scanf("%d",&a[i]);
}}
printf("enter the number you want to search:");
scanf("%d",&x);
if (n%2==0)
 mid=n/2;
else
 mid=(n+1)/2;
for(i=0;i<n;i++){
if (a[mid]==x || a[mid]>x)
 s=s+1;}
if(s>0)
{for(i=0;i<mid;i++){
    if (a[i]==x)
 printf("Number found");}}
else if(a[mid]<x){
for(i=mid;i<n;i++){
if(a[i]==x)
printf("Number found");}}
else{
 printf("Number not found");}
 
 
return 0;
}