/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h> 
#include <stdlib.h> 
struct node 
{ 
     int data; 
     struct node* left; 
     struct node* right; 
}; 
struct node *newnode(int item)
{ 
struct node *temp = (struct node*)malloc(sizeof(struct node)); 
temp->data = item; 
temp->left = NULL; 
temp->right = NULL; 
return(temp);
}
struct node* insert(struct node *node,int value)
{
    if (node==NULL)
    return newnode(value);
    if (value<node->data)
       node->left=insert(node->left,value);
    else if(value>node->data)
       node->right=insert(node->right,value);
    return node;
}
void Inorder(struct node* root) 
{ 
if (root==NULL) 
   return; 
Inorder(root->left);
printf("%d ", root->data); 
Inorder(root->right); 
} 
void main()
{
    struct node *root=NULL;
    root=insert(root,56);
    insert(root,67);
    insert(root,34);
    insert(root,76);
    insert(root,5);
    insert(root,87);
    insert(root,90);
    printf("\ninorder traversal\n");
    Inorder(root);
}
    

